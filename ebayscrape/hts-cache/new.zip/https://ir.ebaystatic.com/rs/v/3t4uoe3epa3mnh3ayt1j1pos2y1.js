

				
				
GH_alertTemplate({
    "iLink" : "http://www.ebay.com/itm/#ITEMID#?_ilink",
    "OUTBIDl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l5997",
    "OUTBIDlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6026",
    "OUTBIDic": "<i class='ghn-ic-ob'/></i>",   
    "BIDITEMl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l5998",
    "BIDITEMlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6027",
    "WATCHITMl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l5999",
    "WATCHITMlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6028",
    "SHOPCARTITMl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6000",
    "SHOPCARTITMlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6029",
    "ITMWONl": "https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6001",
    "ITMWONlp": "https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6030",
    "ITMSOLDl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6002",
    "ITMSOLDlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6031",    

    "COCMPLTl":  "https://postage.ebay.com/ws/eBayISAPI.dll?PrintPostageLabelRedirect&itemId=#ITEMID##TRID#&_trksid=m570.l6003",
    "COCMPLTlp": "https://postage.ebay.com/ws/eBayISAPI.dll?PrintPostageLabelRedirect&itemId=#ITEMID##TRID#&_trksid=m570.l6032",

    "ITMSHPDl" :"http://vod.ebay.com/vod/FetchOrderDetails?ViewPaymentStatus#TRID#&itemId=#ITEMID#&_trksid=m570.l6004", 
    "ITMSHPDlp" :"http://vod.ebay.com/vod/FetchOrderDetails?ViewPaymentStatus#TRID#&itemId=#ITEMID#&_trksid=m570.l6033",
    "BESTOFRl": "http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6005",     
    "BESTOFRlp": "http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6034",    
    "BODECLNDl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6006&boolp=1",  
    "BODECLNDlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6035&boolp=1",  
    
    "CNTROFFRl": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6007&boolp=1", 
    "CNTROFFRlp": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6036&boolp=1", 

    "CNTROFFRl_B": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6345&boolp=1", 
    "CNTROFFRlp_B": "http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6346&boolp=1", 
    
    "CNTROFFRl_S": "http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6339", 
    "CNTROFFRlp_S": "http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6340", 

    "BOACCPTDl" :  "https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6019", 
    "BOACCPTDlp" : "https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6037",
    

    "COACCPTEDl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6020",  
    "COACCPTEDlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6038", 

    "COACCPTEDl_S":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6347",  
    "COACCPTEDlp_S":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6348", 

    "COACCPTEDl_B":"https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6343",  
    "COACCPTEDlp_B":"https://pay.ebay.com/rxo?action=create&item=#ITEMID##TRID#&_trksid=m570.l6344",  
    
    "CODECLNDl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6021&boolp=1",  
    "CODECLNDlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6039&boolp=1", 

    "CODECLNDl_B":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6349&boolp=1",  
    "CODECLNDlp_B":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6350&boolp=1", 

    "CODECLNDl_S":"http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6341",  
    "CODECLNDlp_S":"http://offer.ebay.com/ws/eBayISAPI.dll?ManageBestOffers&itemId=#ITEMID#&_trksid=m570.l6342", 

    
    "OFREXPIREDl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6022",          
    "OFREXPIREDlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6040", 
    "OFRDCLNDACPTl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6023",   
    "OFRDCLNDACPTlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6041", 
    "OFRRETRACTEDl":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6024",
    "OFRRETRACTEDlp":"http://www.ebay.com/itm/#ITEMID#?_trksid=m570.l6042",
    "MSGM2MMSGHDRl":"https://mesg.ebay.com/mesgweb/ViewMessageDetail/0/All/#MSGID#?_trksid=m570.l6025",  
    "MSGM2MMSGHDRlp":"https://mesg.ebay.com/mesgweb/ViewMessageDetail/0/All/#MSGID#?_trksid=m570.l6043", 
    "UCIl":"https://reg.ebay.com/reg/UpdateContactInfo?flow=NOTIFY&_trksid=m570.l7523",
    "UCIlp":"https://reg.ebay.com/reg/UpdateContactInfo?flow=NOTIFY&_trksid=m570.l7524",
    "1":"http://www.ebay.com/myb/PurchaseHistory?_tkrsid=m570.I6828",
    "1p":"http://www.ebay.com/myb/PurchaseHistory?tkrsid=m570.I6832",

	"3":"http://shiptrack.ebay.com/ws/eBayISAPI.dll?BulkShippingLabelLoader&SCSold=true&_trksid=m570.l6829",
	"3p":"http://shiptrack.ebay.com/ws/eBayISAPI.dll?BulkShippingLabelLoader&SCSold=true&_trksid=m570.l6833",
    "6":"https://mesg.ebay.com/mesgweb/ViewMessages/0?_trksid=m570.l6830",
    "6p":"https://mesg.ebay.com/mesgweb/ViewMessages/0?_trksid=m570.l6834",
    "7":"http://www.ebay.com/myb/PurchaseHistory?_tkrsid=m570.I6831",
    "7p":"http://www.ebay.com/myb/PurchaseHistory?_tkrsid=m570.I6835",

    "s0h"  : "<span class='ghn-cd ghn-hl'  >#DIFF#</span>",
    "tlf":{
        "d":"d",
        "h":"h",
        "m":"m",
        "s":"s",
        "e":"Ended"  
    },
    "tmpl_i" : "<li data-id='#ITEMID#' data-uid='#UID#' class='ghn-li-itm #NEW# #TYPE# #UI# #TOUCH#' #P# ><a class='ghn-a-itm' href='#LINK#'><div class='ghn-pop-new'><i class='ghn-new-ic'></i></div><div class='ghn-a-img'><div class='ghn-div-img'><img class=ghn-i src='#imgsrc#'/>#H#</div>#IC#</div><div class='ghn-desc'><span class='ghn-desc-t'>#L10N_t#</span><span class='ghn-desc-d'>#DIFF#</span><span class='ghn-desc-o'>#L10N_s#</span><span class='ghn-desc-a'>#L10N_a#</span></div></a><a href='#' class='ghn-pop-rmv'><i  class='ghn-pop-rmv-ic'>#rmv#</i></a></li>",
    "tmpl_g" : "<li data-id='#ITEMID#' data-uid='#UID#' data-groupid='#GROUPID#' class='ghn-li-itm #NEW# #TYPE# #UI# #TOUCH#' #P#><a class='ghn-a-itm' href='#LINK#'><div class='ghn-pop-new'><i class='ghn-new-ic'></i></div><div class='ghn-a-img'><div class='ghn-div-img'><img class=ghn-i src='#imgsrc#' />#H#<div class='ghn-bmi'></div><div class='ghn-g-num-c'><span class='ghn-g-num'>#NUM#</span></div></div>#IC#</div><div class='ghn-desc'><span class='ghn-desc-t'>#L10N_t# </span><span class='ghn-desc-d'>#DIFF#</span><span class='ghn-desc-o ghellip'>#L10N_s#</span><span class='ghn-desc-a'>#L10N_a#</span></div></a><a href='#' class='ghn-pop-rmv'><i class='ghn-pop-rmv-ic'>#rmv#</i></a></li>",  
    "tmpl_p" : "<div id='ghn-pop-#UID#' data-id='#ITEMID#' data-uid='#UID#' class='ghn-pop-i #TYPE# #UI# #TOUCH#'><div class='ghn-li-itm'><a class='ghn-a-itm' href='#LINKP#'><div class='ghn-pop-new'><i class='ghn-new-ic'></i></div><div class='ghn-a-img'><div class='ghn-div-img'><img class=ghn-i src='#imgsrc#'/>#H#</div>#IC#</div><div class='ghn-desc'><span class='ghn-desc-t' style=''>#L10N_t# </span><span class='ghn-desc-d'>#DIFF#</span><span class='ghn-desc-o'>#L10N_s#</span><span class='ghn-desc-a'>#L10N_a#</span></div></a><a  href='#' class='ghn-pop-rmv'><i class='ghn-pop-rmv-ic'>#rmv#</i></a></div></div>",
    "tmpl_error":  "<div id='ghn-h'>Notifications</div><div id='ghn-err'><span class='ghn-errb'>#TEXT#</span></div><div id='ghn-f'></div>"      
})